module.exports.GAME_STATES = {
  HELP: 'HELP',
  PLAYING: 'PLAYING',
  START: 'START',
};
